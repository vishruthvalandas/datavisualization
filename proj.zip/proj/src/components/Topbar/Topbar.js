import '../../App.css'
function Topbar() {
    return (
      <div class="container">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

    
            <span class="fs-4" style={{fontSize:"500px"}}><h5 class="protest-revolution-regular" style={{fontSize:"50px"}}>Dashboard of climate</h5>
            </span>

  
          
        </header>
      </div>
    );
  }
  export default Topbar;
  
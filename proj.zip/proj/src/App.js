import './App.css';


import Total from './components/Total';
function App() {
  return (
    <div className="App">
     <Total/>
    </div>
  );
}

export default App;
